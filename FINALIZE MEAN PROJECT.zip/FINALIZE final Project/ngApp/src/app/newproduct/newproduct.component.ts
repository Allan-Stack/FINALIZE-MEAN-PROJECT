import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import{ProductModel} from '../productlist/product.model';

@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.css']
})
export class NewproductComponent implements OnInit {

  constructor(private productService:ProductService , private router :Router) { }
  productItem= new ProductModel(null,null,null,null,null,null,null,null);
  
  

  ngOnInit(): void {
  }
 
  AddProduct(){

    this.productService.newproduct(this.productItem);
    alert('YOUR APP IS UNDER REVIEW..THANK YOU!!');
    this.router.navigate(['/special'])

    
   
   
  }
}