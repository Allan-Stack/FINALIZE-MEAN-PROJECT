import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DuorecordComponent } from './duorecord.component';

describe('DuorecordComponent', () => {
  let component: DuorecordComponent;
  let fixture: ComponentFixture<DuorecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DuorecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuorecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
