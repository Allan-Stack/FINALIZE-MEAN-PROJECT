import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-duorecord',
  templateUrl: './duorecord.component.html',
  styleUrls: ['./duorecord.component.css']
})
export class DuorecordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
