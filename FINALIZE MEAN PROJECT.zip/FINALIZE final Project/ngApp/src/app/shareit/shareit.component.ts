import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shareit',
  templateUrl: './shareit.component.html',
  styleUrls: ['./shareit.component.css']
})
export class ShareitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
