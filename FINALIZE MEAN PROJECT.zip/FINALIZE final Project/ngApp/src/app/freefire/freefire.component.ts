import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freefire',
  templateUrl: './freefire.component.html',
  styleUrls: ['./freefire.component.css']
})
export class FreefireComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
