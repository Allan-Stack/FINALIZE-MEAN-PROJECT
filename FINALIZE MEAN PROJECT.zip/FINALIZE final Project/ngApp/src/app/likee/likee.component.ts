import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-likee',
  templateUrl: './likee.component.html',
  styleUrls: ['./likee.component.css']
})
export class LikeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
