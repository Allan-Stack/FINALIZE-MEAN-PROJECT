import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LikeeComponent } from './likee.component';

describe('LikeeComponent', () => {
  let component: LikeeComponent;
  let fixture: ComponentFixture<LikeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LikeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LikeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
