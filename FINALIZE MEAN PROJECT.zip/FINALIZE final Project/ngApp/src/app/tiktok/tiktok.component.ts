import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tiktok',
  templateUrl: './tiktok.component.html',
  styleUrls: ['./tiktok.component.css']
})
export class TiktokComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
