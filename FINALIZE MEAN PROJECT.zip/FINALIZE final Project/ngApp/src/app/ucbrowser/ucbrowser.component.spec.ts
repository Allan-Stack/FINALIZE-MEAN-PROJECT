import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UcbrowserComponent } from './ucbrowser.component';

describe('UcbrowserComponent', () => {
  let component: UcbrowserComponent;
  let fixture: ComponentFixture<UcbrowserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UcbrowserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UcbrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
