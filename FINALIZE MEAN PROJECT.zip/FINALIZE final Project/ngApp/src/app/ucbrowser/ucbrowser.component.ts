import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ucbrowser',
  templateUrl: './ucbrowser.component.html',
  styleUrls: ['./ucbrowser.component.css']
})
export class UcbrowserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
