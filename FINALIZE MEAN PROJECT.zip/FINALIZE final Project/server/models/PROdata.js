const mongoose=require("mongoose")
mongoose.connect('mongodb://localhost:27017/PROdb');


const Schema=mongoose.Schema

const PROSchema=new Schema({

    
   
    productName:String,
    productCode:String,
   
    starRating:Number,
    imageUrl:String,
   
    description:String,
   
});

var PROdata=mongoose.model('Product',PROSchema)

 module.exports=PROdata;

