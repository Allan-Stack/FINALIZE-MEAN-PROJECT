const mongoose=require("mongoose")
mongoose.connect('mongodb://localhost:27017/PROdb');

const Schema=mongoose.Schema

const signSchema=new Schema({

    
    email:String,
   
    password:String

});

var SEntrydata=mongoose.model('signdata',signSchema)

module.exports=SEntrydata;